import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'dependency-injection-component',
  templateUrl: './dependency-injection.component.html',
  styleUrls: ['./dependency-injection.component.css']
})
export class DependencyInjectionComponent{

}
